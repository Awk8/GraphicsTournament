import processing.core.PApplet;public class ProcessingDrawTwo extends PApplet{public static void main(String[] args) {PApplet.main("ProcessingDrawTwo");}public void settings(){size(300,300);}public void setup(){background(255);}public void draw(){
fill(0);
rect(120,120,50,50);
save("playerTwoTemp0.png"); System.exit(0);}}
