import processing.core.PApplet;public class ProcessingDrawOne extends PApplet{public static void main(String[] args) {PApplet.main("ProcessingDrawOne");}public void settings(){size(300,300);}public void setup(){background(255);}public void draw(){
fill(0);
rect(120,120,50,50);
save("playerOneTemp0.png"); System.exit(0);}}
